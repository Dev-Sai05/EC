package com.example.demo;

public class HelloJava {
    public static void greet() {
        System.out.println("Hello from Java!");
    }
}
